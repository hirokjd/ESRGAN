import os
import cv2
import numpy as np
import argparse
from PIL import Image, ImageEnhance

def parse_args():
    parser = argparse.ArgumentParser(description='Apply sharpening to images')
    parser.add_argument('--input', type=str, required=True, help='Input image path')
    parser.add_argument('--output_dir', type=str, default='sharpened', help='Output directory')
    parser.add_argument('--method', type=str, default='both', choices=['pil', 'unsharp', 'both'], help='Sharpening method to use')
    parser.add_argument('--pil_factor', type=float, default=2.0, help='PIL sharpening factor')
    parser.add_argument('--unsharp_amount', type=float, default=2.0, help='Unsharp mask amount')
    return parser.parse_args()

def create_directory(directory):
    if not os.path.exists(directory):
        os.makedirs(directory)

def apply_unsharp_mask(image, kernel_size=(5, 5), sigma=1.0, amount=2.0, threshold=0):
    """Apply unsharp mask filter to sharpen the image"""
    blurred = cv2.GaussianBlur(image, kernel_size, sigma)
    sharpened = float(amount + 1) * image - float(amount) * blurred
    sharpened = np.maximum(sharpened, np.zeros(sharpened.shape))
    sharpened = np.minimum(sharpened, 255 * np.ones(sharpened.shape))
    sharpened = sharpened.round().astype(np.uint8)
    if threshold > 0:
        low_contrast_mask = np.absolute(image - blurred) < threshold
        np.copyto(sharpened, image, where=low_contrast_mask)
    return sharpened

def apply_pil_sharpening(image_path, factor=2.0):
    """Use PIL's ImageEnhance for sharpening"""
    img = Image.open(image_path)
    enhancer = ImageEnhance.Sharpness(img)
    sharpened_img = enhancer.enhance(factor)
    return np.array(sharpened_img)

def main():
    args = parse_args()
    create_directory(args.output_dir)
    
    # Get base filename without extension
    base_name = os.path.splitext(os.path.basename(args.input))[0]
    
    # Read input image
    image = cv2.imread(args.input)
    if image is None:
        print(f"Error: Could not read image {args.input}")
        return
    
    # Apply selected sharpening methods
    if args.method in ['unsharp', 'both']:
        unsharp_mask = apply_unsharp_mask(image, amount=args.unsharp_amount)
        cv2.imwrite(os.path.join(args.output_dir, f"{base_name}_unsharp.png"), unsharp_mask)
        print(f"Unsharp mask saved to {args.output_dir}/{base_name}_unsharp.png")
    
    if args.method in ['pil', 'both']:
        pil_sharpened = apply_pil_sharpening(args.input, factor=args.pil_factor)
        cv2.imwrite(os.path.join(args.output_dir, f"{base_name}_pil.png"), cv2.cvtColor(pil_sharpened, cv2.COLOR_RGB2BGR))
        print(f"PIL sharpening saved to {args.output_dir}/{base_name}_pil.png")
    
    print(f"Sharpening completed successfully.")

if __name__ == "__main__":
    main() 