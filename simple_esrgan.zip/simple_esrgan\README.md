# Simple Image Sharpening

This is a simplified version of the ESRGAN project that focuses only on the two most effective sharpening methods for enhancing super-resolution images.

## Sharpening Methods

1. **Unsharp Mask**: A traditional sharpening technique that enhances edges by subtracting a blurred version of the image from the original.

2. **PIL Sharpening**: Uses Python Imaging Library's built-in sharpening filter which provides excellent results with minimal artifacts.

## Usage

```bash
python simple_sharpen.py --input <input_image_path> [options]
```

### Options

- `--input`: Path to the input image (required)
- `--output_dir`: Directory to save output images (default: 'sharpened')
- `--method`: Sharpening method to use: 'pil', 'unsharp', or 'both' (default: 'both')
- `--pil_factor`: Sharpening factor for PIL method (default: 2.0)
- `--unsharp_amount`: Amount parameter for unsharp mask (default: 2.0)

### Examples

Apply both sharpening methods with default parameters:
```bash
python simple_sharpen.py --input results/baboon_rlt.png
```

Apply only PIL sharpening with increased strength:
```bash
python simple_sharpen.py --input results/baboon_rlt.png --method pil --pil_factor 2.5
```

Apply only unsharp mask with custom strength:
```bash
python simple_sharpen.py --input results/baboon_rlt.png --method unsharp --unsharp_amount 1.8
```

## Requirements

- Python 3.6+
- OpenCV (cv2)
- NumPy
- Pillow (PIL)

## Original ESRGAN

This is a simplified version of the ESRGAN project. The original ESRGAN (Enhanced Super-Resolution Generative Adversarial Network) is a state-of-the-art method for single image super-resolution. For the full ESRGAN implementation, please refer to the original repository.

## Acknowledgments

This work builds upon the original ESRGAN paper:

```
@InProceedings{wang2018esrgan,
    author = {Wang, Xintao and Yu, Ke and Wu, Shixiang and Gu, Jinjin and Liu, Yihao and Dong, Chao and Qiao, Yu and Loy, Chen Change},
    title = {ESRGAN: Enhanced super-resolution generative adversarial networks},
    booktitle = {The European Conference on Computer Vision Workshops (ECCVW)},
    month = {September},
    year = {2018}
}
``` 